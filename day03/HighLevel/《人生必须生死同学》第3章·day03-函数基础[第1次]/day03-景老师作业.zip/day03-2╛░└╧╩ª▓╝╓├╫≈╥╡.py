#!/usr/bin/env python

import copy
import os



sql_file = 'user_info.sql'

temp_file = 'temp.sql'

file_field = ('id','name','age','phone','job')

# 支持的比较运算符
support_statement = ['like', '>', '=', '<', '>=', '<=']

# 存储报错信息
error_info = {}

# 存储用户查询,符合匹配条件的所有行
user_view = []

# 最终要输出的查询结果
select_msg = []

# 用户查询记录临时字典信息
msg_dic = {}


# 存储用户创建信息
create_info = {}

def get_help():
    msg = '''\
    
  查询语法: select <field_1>[,field_2,..] where EXPRESSION
  例子:     select id,name where phone like 133

  删除语法: delete USER_ID
  例子:    delete 1

  输入 create 进入创建用户模式
  输入 h 获取帮助!
  输入 q 退出程序!
    '''

    print(msg)
    return



def get_user_command(statement_list):
    result = statement_list[0]
    return result

def statement_check_first_key(statement_str,statement_list):
    '''检查用户输入的第一个操作符是否合法'''

    fun = ['select','set','delete','create']


    if statement_str.strip() == '':
        return False

    if statement_list[0] in fun:
        return True
    else:
        return False


def statement_check_field(statement_list):
    '''检查用户输入的字段是否合法'''

    field_list = get_user_field(statement_list)

    # 判断用户输入是否为*
    count_start = ''.join(field_list)

    if count_start == '*':
        return True



    # if statement_list

    # 判断用户输入的字段是否在文件内
    for i in field_list:
        if i not in file_field:
            return False
    return True


def statement_check_where(statement_list):
    '''检查是否包含where关键字'''
    if len(statement_list) > 2 and statement_list[2] == 'where':
        return True
    else:
        return False


def statement_check_where_condition(statement_list, support_statement):


    where_condition = get_user_where_condition(statement_list, support_statement)

    if len(where_condition) != 3:
        return False

    # 如果用户输入的比较运算符不在支持的列表内，返回False
    if where_condition[1] not in support_statement:
        return False

    # 如果用户输入的字段不在文件内，返回False
    elif where_condition[0] not in file_field:
        return False
    return True


def statement_check(statement_str,statement_list,support_statement):
    '''检查用户输入语句是否合法'''


    # 检查是否为select ,set,delete,create
    if not statement_check_first_key(statement_str, statement_list):
        return False

    # 检查del语法是否正确
    elif statement_list[0] == 'delete':
        if len(statement_list) == 2 and statement_list[1].isdigit():
            return True

    # 检查是否包含where
    elif not statement_check_where(statement_list):
        return False

    # 检查用户输入字段是否包含在文件内
    elif not statement_check_field(statement_list):
        return False

    # 检查where后面条件是否合法
    elif not statement_check_where_condition(statement_list, support_statement):
        return False

    else:
        return True


def get_user_field(statement_list):
    if statement_list[1] == '*':
        return file_field
    field_list = statement_list[1].split(',')
    return field_list


def get_user_where_condition(statement_list, support_statement):
    '''获取用户输入的条件表达式'''

    where_addr = statement_list.index('where')

    where_condition = statement_list[where_addr + 1:]


    if len(where_condition) > 1:
        if where_condition[1] == 'like':
            return where_condition

    where_condition_str = ''.join(statement_list[where_addr+1:])


    # 用户输入的比较运算符
    comparison = ''

    # 拿到用户输入的比较运算符
    for i in where_condition_str:
        if i in support_statement:
            comparison += i

    where_condition = where_condition_str.split(comparison)
    where_condition.insert(1, comparison)

    return where_condition



def check_gt(line, user_input_where_condition, user_input_where_condition_index):

    # 判断文件内容是否为数字，一般只有数字才能比大小，字符串比大小没有意义
    if user_input_where_condition[2].isdigit():
        # 如果文件内容符合用户输入条件，则执行添加到用户显示层的操作
        if int(line[user_input_where_condition_index]) > int(user_input_where_condition[2]):
            add_to_user_view(*line)

    return True


def check_lt(line, user_input_where_condition, user_input_where_condition_index):
    if user_input_where_condition[2].isdigit():
        if int(line[user_input_where_condition_index]) < int(user_input_where_condition[2]):
            add_to_user_view(*line)
    return True



def add_to_user_view(*args):
    '''将查询结果添加至用户显示层'''

    temp = {}
    # 接收查询结果，将结果以字典形式排列，
    # 如{'id': '2', 'name': 'Egon', 'age': '23', 'phone': '13304320533', 'job': 'Tearcher'}
    for i in range(len(args)):
        temp[file_field[i]] = args[i]

    # 将结果添加到用户显示层
    user_view.append(temp)

    return True


def select_result_filter(user_input_field):
    '''根据用户筛选条件进行选择性输出'''

    if len(user_view) == 0:
        return None


    if ''.join(user_input_field) == '*':

        select_msg.extend(user_view)
        return True

    for i in user_view:
        for j in user_input_field:
            msg_dic[j] = i[j]

        select_msg.append(copy.copy(msg_dic))


    return True


def print_filter_result(user_input_field,select_msg):
    '''输出用户查询结果'''

    if ''.join(user_input_field) == '*':
        user_input_field = file_field

    print('-' * 66)
    for i in user_input_field:
        print(i.ljust(15, ' '),end="")
    else:
        print("")


    for i in select_msg:
        for j in user_input_field:
            print(i[j].ljust(15, ' '), end="")
        print("")
    else:
        print('-' * 66)




def select_func(statement_lis):



    # 获取用户输入的字段
    user_input_field = get_user_field(statement_list)

    user_input_where_condition = get_user_where_condition(statement_list,support_statement)

    # 用户输入的where 条件字段索引
    user_input_where_condition_index = file_field.index(user_input_where_condition[0])


    # 打开文件进行查询
    with open(sql_file,'r',encoding='utf-8') as f:

        # 如果用户是进行模糊查询
        if user_input_where_condition[1] == 'like':
            for line in f:
                line = line.strip().split(',')
                # 如果用户输入的条件，能匹配上文件内容，则将该行文件内容，添加至用户显示层
                if user_input_where_condition[2] in line[user_input_where_condition_index]:
                    add_to_user_view(*line)


        # 如果用户不是进行模糊查询
        else:
            for line in f:
                line = line.strip().split(',')
                # 如果用户的比较运算符是>
                if user_input_where_condition[1] == '>':
                    temp_result = check_gt(line, user_input_where_condition, user_input_where_condition_index)
                    if not temp_result:
                        return False

                # 如果用户的比较运算符是<
                elif user_input_where_condition[1] == '<':
                    temp_result = check_lt(line, user_input_where_condition, user_input_where_condition_index)
                    if not temp_result:
                        return False

                # 如果用户的比较运算符是=
                elif user_input_where_condition[1] == '=':
                    if user_input_where_condition[2] == line[user_input_where_condition_index]:
                        add_to_user_view(*line)

                # 如果用户输入的比较运算符是>=
                elif user_input_where_condition[1] == '>=':
                    if user_input_where_condition[2].isdigit():
                        if  int(line[user_input_where_condition_index]) >= int(user_input_where_condition[2]):
                            add_to_user_view(*line)
                    else:
                        return False

                # 如果用户输入的比较运算符是<=
                elif user_input_where_condition[1] == '<=':
                    if user_input_where_condition[2].isdigit():
                        if  int(line[user_input_where_condition_index]) <= int(user_input_where_condition[2]):
                            add_to_user_view(*line)
                    else:
                        return False



    ret = select_result_filter(user_input_field)
    if ret == None:
        return False


    # 输出查询结果
    print_filter_result(user_input_field, select_msg)

    # 清空用户查询记录
    select_msg.clear()

    # 清空临时用户信息
    user_view.clear()

    # 清空用户查询记录临时字典信息
    msg_dic.clear()

    return True



def check_delete_id(statement_list):
    '''检查删除id是否合法'''

    if len(statement_list) == 2:
        if statement_list[1].isdigit():
            return True
        else:
            return False


def del_func(statement_list):

    flag = False

    user_id = statement_list[1]

    with open(sql_file, 'r', encoding='utf-8') as src_sql_file:
        for line in src_sql_file:
            if user_id in line.split(','):
                flag = True
                continue
            else:
                user_view.append(line)
    with open(temp_file, 'w', encoding='utf-8') as dst_sql_file:
        if flag:
            for i in user_view:
                dst_sql_file.write(i)


        else:
            return False

    user_view.clear()
    os.remove(sql_file)
    os.rename(temp_file, sql_file)

    return flag



def get_user_set_field(statement_list):
    '''后去用户的'''
    field_list = statement_list[1].split('=')
    return field_list

def check_set_field(statement_list):
    '''检查用户输入的字段是否合法'''

    user_field = get_user_set_field(statement_list)

    if len(user_field) != 2:
        return False

    if user_field[0] in file_field:
        return True
    else:
        return False



def change_file(user_set_field):
    flag = False
    user_id = statement_list[1]

    with open(sql_file, 'r', encoding='utf-8') as src_sql_file:
        for line in src_sql_file:
            if user_id in line.split(','):
                flag = True
                continue
            else:
                user_view.append(line)

    # with open(temp_file, 'w', encoding='utf-8') as dst_sql_file:
    #     if flag:
    #         print(user_view)
    #         for i in user_view:
    #             dst_sql_file.write(i)
    #     else:
    #         return False

    print(user_view)
    user_view.clear()
    os.remove(sql_file)
    os.rename(temp_file, sql_file)

    return flag



def set_func(statement_list):
    user_set_field = get_user_set_field(statement_list)
    check_set_field_result = check_set_field(statement_list)
    if check_set_field_result:
        change_file(user_set_field)
    else:
        return False


def add_create_info_to_file(last_user_id):
    '''将用户创建的信息写入到文件中'''

    last_user_id = int(last_user_id)+1

    msg = '%s' % str(last_user_id)
    with open(sql_file, 'a', encoding='utf-8') as f:
        for i in create_info:
            msg += ',%s'% create_info[i]
        f.write('\n')
        f.write(msg)



def get_create_user_info(need_user_input_create_info):
    '''获取用户输入的创建用户的信息'''

    for i in need_user_input_create_info:
        create_info[i] = input('请输入用户%s: '%i)




def get_last_user_id(need_user_input_create_info):
    last_user_id = ''
    with open(sql_file, 'r', encoding='utf-8') as f:
        for line in f:
            pass
        else:
           last_user_id = line.split(',')[0]
    return last_user_id


def create_func():
    # 获取用户输入

    need_user_input_create_info = file_field[1:]

    get_create_user_info(need_user_input_create_info)

    # 获取当前文件内最后一个用户的用户id
    last_user_id = get_last_user_id(need_user_input_create_info)

    # 写入到文件
    add_create_info_to_file(last_user_id)


    create_info.clear()
    return True


sql_error_count = 0

get_help()

while 2 >= sql_error_count:

    user_input_str = input('请输入sql语句: ')

    # 将用户输入去除前后空格，生成一个新的列表
    statement_list = user_input_str.strip().split()

    # 检查用户输入的第一个关键字是否合法
    first_key_result = statement_check_first_key(user_input_str, statement_list)

    if not first_key_result:
        sql_error_count += 1
        if sql_error_count > 2:
            continue
        print('语法错误，请重新输入! ')
        continue

    # 获取用户输入的第一个指令
    user_command = get_user_command(statement_list)

    if user_command.upper() == 'Q':
        print('正在退出程序...')
        break

    elif user_command.upper() == 'H':
        get_help()
        continue

    elif user_command == 'create':
        create_func()
        print('写入成功!')
        continue


    elif user_command == 'select':

        # 检查用户输入的查询语句是否合法
        statement_check_result = statement_check(user_input_str, statement_list, support_statement)

        # 如果用户输入不合法，要求重新输入，并将错误次数+1
        if not statement_check_result:
            sql_error_count += 1
            if sql_error_count > 2:
                continue
            print('语法错误，请重新输入! ')
            continue
        else:
            sql_error_count = 0

        # 执行查询操作
        ret = select_func(statement_list)
        if not ret:
            print('没有匹配到数据..')


    elif user_command == 'set':
        # 这个set没时间去做了，不用测试了

        ret = set_func(statement_list)
        if ret:
            print('修改成功.')
        else:
            print('修改失败.')


    elif user_command == 'delete':

        # 检查用户输入的id是否合法
        check_delete_id_result = check_delete_id(statement_list)

        if not check_delete_id_result:
            sql_error_count += 1
            if sql_error_count > 2:
                continue
            print('语法错误，请重新输入! ')
            continue
        else:
            sql_error_count = 0

        ret  = del_func(statement_list)

        if ret:
            print('删除成功.')
        else:
            print('删除失败,用户不存在')



else:
    print('错误次数过多，请重新启动程序! ')






# 错误用例
#select host,user where a> b
#select id,name,phone, age where phone like 133

#select id,age where id > a
#select *,a,b where id > 1


# 正确用例
#select id,age where phone like  133
#select * where phone like 133
#select * where name like ne

#select id,age where id > 1
#select id,age where id = 3
#select id,age,name where id< 3
#select id,age,name,phone where id <= 3
#select id,age where id >=3
#select id,age where id >= 4
#select * where id >= 2

#select * where job=IT
#select * where job=Tearcher
#select * where age >= 22
