#!/usr/bin/env python



#      约定
# 1. 用户账号密码存在在user_info.txt中，以空格为分隔符
# 2. 用户密码不允许包含空格、tab键
# 3.

# 商品信息
commodity_info = [
    {'product_name': '电脑', 'price': 1999},
    {'product_name': '键盘', 'price': 20},
    {'product_name': '鼠标', 'price': 20},
    {'product_name': '显示器', 'price': 888},
]

# 用户信息存放文件
user_info_file = 'user_info.txt'

# 用户购物车
shopping_cart = {}

# 首页信息
index_msg = '''\
1. 登录
2. 注册
3. 购物
4. 退出
'''

user_login_status = False



def login():
    login_error_count = 1
    while login_error_count <= 3:
        # 执行user_input函数，获取用户输入
        user_input_name,user_input_password = user_input_account()

        # 判断用户是否存在
        user_is_exist = user_check(user_input_name)
        if not user_is_exist:
            print('用户或密码错误，请重新输入')
            login_error_count += 1
            continue


        with open(user_info_file,'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip().split()
                if user_input_name == line[0] and user_input_password == line[1]:
                    return True
            else:
                print('用户或密码错误，请重新输入')
                login_error_count += 1
    else:
        print('错误次数过多，请重新启动程序')


def user_check(username):
    # 验证用户是否已存在
    with open(user_info_file, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip().split()
            if username == line[0]:
                # 返回Ture,表示该用户已存在
                return True
        else:
            # 返回False，表示该用户不存在
            return False


def register(username, password):
    '''用户注册函数'''
    if username.strip() == '':
        print('输入的用户名不合法，请重新输入')

    elif user_check(username):
        print('该用户已存在,请重新输入')
        return False
    else:
        with open(user_info_file,'a',encoding='utf-8') as f:
            f.write('%s %s\n' % (username, password))
            return True





def print_commodity_info():
    '''打印所有商品信息'''

    print('-' * 20 + '商品列表' + '-' * 20)
    print('编号'.center(10, ' '),'名称'.ljust(31, ' '), '价格'.ljust(10, ' '))

    for i in commodity_info:
        print(str(commodity_info.index(i)+1).center(12, ' '),
              str(i['product_name']).ljust(31, ' '),
              str(i['price']).ljust(10, ' ')
              )


    print('-' * 20 + '商品列表' + '-' * 20)



def add_commodity(user_input_commodity_str):
    '''添加商品函数'''

    if not user_input_commodity_str.isdigit():
        return False

    user_input_commodity_int = int(user_input_commodity_str)
    # 判断用户输入是否在商品列表内



    if user_input_commodity_int > len(commodity_info) or user_input_commodity_int <= 0:
        return False




    # 如果用户输入的编号在商品列表内，直接添加数量
    if user_input_commodity_str in shopping_cart:
        shopping_cart[user_input_commodity_str]['count'] += 1
        shopping_cart[user_input_commodity_str]['sum'] = shopping_cart[user_input_commodity_str]['count'] \
                                                     * shopping_cart[user_input_commodity_str]['price']

    else:
        shopping_cart[user_input_commodity_str] = {}
        shopping_cart[user_input_commodity_str]['serial'] = user_input_commodity_int
        shopping_cart[user_input_commodity_str]['price'] = commodity_info[user_input_commodity_int-1]['price']
        shopping_cart[user_input_commodity_str]['product_name'] = \
            commodity_info[user_input_commodity_int-1]['product_name']

        shopping_cart[user_input_commodity_str]['count'] = 1
        shopping_cart[user_input_commodity_str]['sum'] = shopping_cart[user_input_commodity_str]['count'] \
                                                     * shopping_cart[user_input_commodity_str]['price']

    return True






def del_commodity(user_input_commodity_str):
    '''删除商品函数'''

    if not user_input_commodity_str.isdigit():
        return False




    user_input_commodity_int = int(user_input_commodity_str)
    # 判断用户输入是否在商品列表内



    if user_input_commodity_int > len(commodity_info) or user_input_commodity_int <= 0:
        return False






    # 如果用户输入的编号在商品列表内，直接添加数量
    if user_input_commodity_str in shopping_cart:

        shopping_cart[user_input_commodity_str]['count'] -= 1

        shopping_cart[user_input_commodity_str]['sum'] = shopping_cart[user_input_commodity_str]['count'] \
                                                     * shopping_cart[user_input_commodity_str]['price']
        if shopping_cart[user_input_commodity_str]['count'] == 0:
            del shopping_cart[user_input_commodity_str]

    else:
        print('购物车内没有该商品...')
        print_shopping_cart()
        return False

    print_shopping_cart()
    return True



def compute_total_prices():
    total_prices = 0
    for i in shopping_cart:
        total_prices += shopping_cart[i]['sum']

    return  total_prices


def print_shopping_cart():
    '''打印购物车函数'''

    print('-' * 20 + '购物车列表' + '-' * 20)
    print('编号'.center(12, ' '),'名称'.ljust(12, ' '), '单价'.ljust(12, ' '), '数量'.ljust(10, ' '),'合计'.ljust(10, ' '))
    print(shopping_cart)
    for i in shopping_cart:
        print(str(shopping_cart[i]['serial']).center(12, ' '),
              str(shopping_cart[i]['product_name']).center(12, ' '),
              str(shopping_cart[i]['price']).ljust(12, ' '),
              str(shopping_cart[i]['count']).ljust(12, ' '),
              str(shopping_cart[i]['sum']).ljust(10, ' '),
              )
    print('-' * 20 + '购物车列表' + '-' * 20)

    total_prices = compute_total_prices()
    print('总价: %s'% total_prices)

    return total_prices




def shopping(user_login_status):
    '''购物函数'''

    total_prices = 0
    action = True

    if not user_login_status:
        print('进入购物前请先登录!')
        user_login_status  = login()
    if not user_login_status:
        return False


    while True:
        user_input_money = input('请输入要充值的金额: ')

        if  user_input_money.isdigit():
            break
        else:
            print('输入有误，请输入数字')

    user_input_money = int(user_input_money)
    # 输出商品信息
    print_commodity_info()

    while action:
        # 判断购物车的总价值是否超过了用户充值的金额
        while total_prices > user_input_money:
            user_input_commodity_str = input('请输入你要删除的商品编号: ')
            if user_input_commodity_str.upper() == 'Q':
                return False
            del_commodity(user_input_commodity_str)
            total_prices = compute_total_prices()



        user_input_commodity_str = input('请输入你要购买的商品编号: ')

        if user_input_commodity_str.upper() == 'N':
            print_shopping_cart()
            total_prices = compute_total_prices()
            print('本次共消费: %s, 账户余额: %s' % (total_prices, user_input_money-total_prices))
            return True

        if user_input_commodity_str.upper() == 'Q':
            return False

        add_commodity_result = add_commodity(user_input_commodity_str)
        if not add_commodity_result:
            print('输入的商品不存在，请重新输入!')
            continue

        total_prices = print_shopping_cart()
















def user_input_account():
    user_input_name = input('请输入用户名: ')
    user_input_password = input('请输入密码: ')

    return user_input_name,user_input_password



def index_print():
    # 用户运行程序，开始输出首页信息
    print(index_msg)

    user_input_num = input('请输入序号，选择你要做的操作:  ')

    return user_input_num


flag = True
user_is_login = False
while flag:

    user_input_num = index_print()

    if user_input_num == '1':
        login_result = login()
        if login_result:
            user_login_status = True
            shopping(user_login_status)
            break
        else:
            break


    elif user_input_num == '2':
        while True:
            user_input_name, user_input_password = user_input_account()
            register_result = register(user_input_name, user_input_password)

            if register_result:
                print('注册成功!~~~')
                break



    elif user_input_num == '3':
        shopping_result = shopping(user_login_status)
        if not shopping_result:
            print('正在退出..')
        break

    elif user_input_num == '4':
        break

    else:
        print('输入有误，请重新输入')
